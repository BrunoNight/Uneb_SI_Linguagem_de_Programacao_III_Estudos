public class MeuRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("Olá " + Thread.currentThread().getName());
    }
}