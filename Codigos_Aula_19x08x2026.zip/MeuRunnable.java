public class MeuRunnable implements Runnable { // Vai startar threads (Iniciar threads)
    public void run() {
        System.out.println("Olá mundo!");
        String name = Thread.currentThread().getName();
        System.out.println(name);
    }
}

// Extra: Lock para algo dentro de alguma função em determinada condição