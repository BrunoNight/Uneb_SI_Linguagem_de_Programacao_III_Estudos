public class Threads_1 { // Detém o main, que é aonde serão mostrados o que está dentro do main ao apertar "Run"
	public static void main(String[] args) {
		Thread t = Thread.currentThread(); // Extensão da classe Threads_1
		System.out.println(t.getName());
		// Runnabloe meuRunnable = new MeuRunnable();
		
		// Nova Thread
		Thread t0 = new Thread(new MeuRunnable()); // Instancia a classe MeuRunnable (Instanciando uma nova thread)
		// t0.run();
		
		// Nova Thread
		Thread t1 = new Thread(new MeuRunnable());
		// t1.run(); // Deixando minha thread como principal (mesmo poder de execução da thread main)
		// t1.start(); // Começa a ocorrer conconrrência computacional por recursos (acaba ficando com prioridade main)
		
		// Runnable com lambda (lambda é função dentro de uma função)
		Thread t2 = new Thread(() -> System.out.println("LP-III"));
		// t2.start(); // Responderá à thread main? Verificar...
		
		Thread t3 = new Thread(new MeuRunnable());
		// t3.start(); // Executando em uma nova thread
		
		t0.start();
		t1.start();
		t2.start();
		t3.start();
	}
}