public class Thread_1 {
    public static void main(String[] args) {
        Thread t = Thread.currentThread(); // Cria thread com a thread principal "main"
        System.out.println("Olá " + t.getName()); // Mostra nome da thread principal, que é "main"
    }
}